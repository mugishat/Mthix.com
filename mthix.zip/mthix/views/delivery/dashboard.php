<div class="page-head"><div><h1>Delivery dashboard</h1><p class="muted">Accept jobs, deliver, get paid when the order completes.</p></div><a class="btn" href="/delivery/jobs">Find jobs (<?= (int)$open ?>)</a></div>
<div class="grid g4 mb">
  <div class="card stat"><span class="ico">₣</span><div><div class="lbl">Available earnings</div><div class="val"><?= money($bal['available']) ?></div></div></div>
  <div class="card stat"><span class="ico a">⏳</span><div><div class="lbl">Pending earnings</div><div class="val"><?= money($bal['pending']) ?></div></div></div>
  <div class="card stat"><span class="ico b">🚚</span><div><div class="lbl">Active now</div><div class="val"><?= (int)$active ?></div></div></div>
  <div class="card stat"><span class="ico p">✓</span><div><div class="lbl">Delivered (all time)</div><div class="val"><?= (int)$done ?></div></div></div>
</div>
<h2>Today's deliveries</h2>
<?php if (!$today): ?><div class="card empty">Nothing today yet. <a href="/delivery/jobs">See available jobs</a>.</div>
<?php else: ?><div class="stack"><?php foreach ($today as $j): echo \App\Core\View::partial('job_card', ['j' => $j]); endforeach; ?></div><?php endif; ?>
