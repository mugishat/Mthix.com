<div class="page-head"><h1>Orders & earnings</h1><div class="muted">Available <b><?= money($bal['available']) ?></b> · Pending <b><?= money($bal['pending']) ?></b> · <a href="/wallet">Withdraw</a></div></div>
<div class="card"><?= \App\Core\View::partial('partner_orders', ['rows' => $rows]) ?></div>
