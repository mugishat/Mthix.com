<?php $link = url('/?a=' . $ref); ?>
<div class="page-head"><div><h1>Affiliate dashboard</h1><p class="muted">Earn on every purchase made by people you refer.</p></div></div>
<div class="grid g4 mb">
  <div class="card stat"><span class="ico">₣</span><div><div class="lbl">Available</div><div class="val"><?= money($bal['available']) ?></div></div></div>
  <div class="card stat"><span class="ico a">⏳</span><div><div class="lbl">Pending</div><div class="val"><?= money($bal['pending']) ?></div></div></div>
  <div class="card stat"><span class="ico b">⛓</span><div><div class="lbl">Clicks</div><div class="val"><?= number_format($clicks) ?></div></div></div>
  <div class="card stat"><span class="ico p">%</span><div><div class="lbl">Orders · conversion</div><div class="val"><?= (int)$orders ?> · <?= $conv ?>%</div></div></div>
</div>
<div class="grid g-main">
  <div class="card"><h2>Clicks (14 days)</h2><?= chart_bars(array_map(fn($d) => date('j M', strtotime($d)), array_keys($days)), array_values($days)) ?></div>
  <div class="card"><h2>Your referral link</h2>
    <p><code style="word-break:break-all"><?= e($link) ?></code></p>
    <div class="row"><button class="btn" type="button" data-copy="<?= e($link) ?>">Copy link</button>
    <button class="btn btn-light" type="button" data-copy="<?= e($ref) ?>">Copy code</button></div>
    <p class="small muted mt">Anyone who opens this link and buys within 30 days earns you a commission. You cannot earn from your own purchases.</p></div>
</div>
<div class="card mt"><div class="card-head"><h2>Recent orders</h2><a href="/affiliate/orders">View all</a></div>
<?= \App\Core\View::partial('partner_orders', ['rows' => $recent]) ?></div>
