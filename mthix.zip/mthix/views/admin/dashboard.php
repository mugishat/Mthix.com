<?php use App\Core\Auth; ?>
<div class="page-head"><div><h1>Admin dashboard</h1><div class="muted">Welcome back! Here’s what’s happening with MTHIX today.</div></div></div>

<div class="grid g4 mb">
  <?php foreach ([
    ['Total users', number_format($kpi['users']), ''], ['Paid orders', number_format($kpi['orders']), 'b'],
    ['Platform revenue (commission)', money($kpi['revenue']), 'p'], ['Goods sold (GMV)', money($kpi['gmv']), 'a'],
    ['Active sellers', number_format($kpi['sellers']), ''], ['Active products', number_format($kpi['products']), 'b'],
    ['Payouts waiting', money($kpi['payouts']), 'a'],
  ] as [$l, $v, $c]): ?>
    <div class="card stat"><div class="ico <?= $c ?>">◆</div><div><div class="lbl"><?= e($l) ?></div><div class="val"><?= e($v) ?></div></div></div>
  <?php endforeach; ?>
  <div class="card"><div class="lbl muted">Needs attention</div>
    <div class="small mt">
      <?php if (Auth::hasAny(['admin','support_admin'])): ?><a href="/admin/kyc">KYC to review</a> <b><?= $queues['kyc'] ?></b><br><a href="/admin/disputes">Open disputes</a> <b><?= $queues['disputes'] ?></b><br><?php endif; ?>
      <?php if (Auth::hasAny(['admin','finance_admin'])): ?><a href="/admin/withdrawals">Withdrawals to process</a> <b><?= $queues['withdrawals'] ?></b><?php endif; ?>
    </div></div>
</div>

<div class="grid g-main mb">
  <div class="card"><div class="card-head"><h2>Sales (last 14 days)</h2><span class="muted small">Order value paid per day</span></div><?= chart_line($labels, ['Sales' => $vals]) ?></div>
  <div class="card"><div class="card-head"><h2>Orders by status</h2></div>
    <?php if ($status): ?><div class="row"><?= chart_donut($status, (string)array_sum($status), 'Total orders', 150) ?><div class="grow"><?= chart_legend($status) ?></div></div><?php else: ?><div class="empty">No orders yet.</div><?php endif; ?>
  </div>
</div>

<div class="grid g3 mb">
  <div class="card"><div class="card-head"><h2>Recent orders</h2><?php if (Auth::hasAny(['admin','support_admin'])): ?><a href="/admin/orders" class="small">View all</a><?php endif; ?></div>
    <div class="table-wrap"><table><thead><tr><th>Order</th><th>Buyer</th><th class="right">Total</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($recent as $o): ?><tr>
      <td><?php if (Auth::hasAny(['admin','support_admin'])): ?><a href="/admin/orders/<?= e($o['code']) ?>"><?= e($o['code']) ?></a><?php else: ?><?= e($o['code']) ?><?php endif; ?></td>
      <td><?= e($o['buyer']) ?></td><td class="right"><?= money($o['total']) ?></td><td><?= status_badge($o['status']) ?></td></tr>
    <?php endforeach; ?><?php if (!$recent): ?><tr><td colspan="4" class="empty">No orders yet.</td></tr><?php endif; ?></tbody></table></div></div>

  <div class="card"><div class="card-head"><h2>Top sellers</h2></div>
    <div class="table-wrap"><table><thead><tr><th>#</th><th>Store</th><th class="right">Orders</th><th class="right">Revenue</th></tr></thead><tbody>
    <?php foreach ($topSellers as $i => $s): ?><tr><td><?= $i + 1 ?></td><td><?= e($s['name']) ?></td><td class="right"><?= (int)$s['orders'] ?></td><td class="right"><?= money($s['revenue']) ?></td></tr>
    <?php endforeach; ?><?php if (!$topSellers): ?><tr><td colspan="4" class="empty">No sales yet.</td></tr><?php endif; ?></tbody></table></div></div>

  <div class="card"><div class="card-head"><h2>System health</h2></div>
    <?php foreach ($health as [$name, $ok, $msg]): ?>
      <div class="row spread" style="padding:7px 0;border-bottom:1px solid #f0f2f6"><span><?= e($name) ?></span><span class="<?= $ok ? 'pos' : 'neg' ?>"><?= $ok ? '● ' : '▲ ' ?><?= e($msg) ?></span></div>
    <?php endforeach; ?></div>
</div>
