<div class="page-head"><h1>Orders</h1></div>
<form class="filters" method="get">
  <div class="field"><label for="q">Search</label><input id="q" type="search" name="q" value="<?= e($q) ?>" placeholder="Code, buyer or store"></div>
  <div class="field"><label for="st">Status</label><select id="st" name="status" data-autosubmit><option value="">All</option>
    <?php foreach (array_keys(App\Services\OrderStateMachine::FLOW) as $s): ?><option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= status_label($s) ?></option><?php endforeach; ?></select></div>
  <button class="btn btn-light" type="submit">Filter</button>
</form>
<div class="card"><div class="table-wrap"><table>
  <thead><tr><th>Order</th><th>Buyer</th><th>Store</th><th>Placed</th><th class="right">Total</th><th>Status</th></tr></thead><tbody>
  <?php foreach ($rows as $o): ?><tr><td><a href="/admin/orders/<?= e($o['code']) ?>"><?= e($o['code']) ?></a></td><td><?= e($o['buyer']) ?></td><td><?= e($o['store_name']) ?></td>
    <td class="small nowrap"><?= e(dt($o['created_at'])) ?></td><td class="right"><?= money($o['total']) ?></td><td><?= status_badge($o['status']) ?></td></tr>
  <?php endforeach; ?><?php if (!$rows): ?><tr><td colspan="6" class="empty">No orders match.</td></tr><?php endif; ?></tbody></table></div>
  <?= App\Core\View::partial('admin_pager', ['pg' => $pg]) ?></div>
