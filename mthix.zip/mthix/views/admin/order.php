<div class="crumbs"><a href="/admin/orders">Orders</a> › <?= e($o['code']) ?></div>
<div class="page-head"><div><h1><?= e($o['code']) ?> <?= status_badge($o['status']) ?></h1>
  <div class="muted">Placed <?= e(dt($o['created_at'])) ?> by <?= e($o['buyer']) ?> (<?= e($o['buyer_email']) ?>) · store <?= e($o['store_name']) ?></div></div></div>

<div class="grid g-main mb">
  <div class="stack">
    <div class="card"><h2>Items</h2><div class="table-wrap"><table><thead><tr><th>Product</th><th class="right">Unit</th><th class="right">Qty</th><th class="right">Total</th></tr></thead><tbody>
      <?php foreach ($items as $i): ?><tr><td><?= e($i['product_name']) ?><div class="small muted"><?= e($i['variant_label']) ?></div></td><td class="right"><?= money($i['unit_price']) ?></td><td class="right"><?= (int)$i['qty'] ?></td><td class="right"><?= money($i['line_total']) ?></td></tr><?php endforeach; ?></tbody></table></div>
      <div class="totals mt"><div><span>Products</span><span><?= money($o['subtotal']) ?></span></div><div><span>Delivery (<?= e($o['delivery_method']) ?>)</span><span><?= money($o['delivery_fee']) ?></span></div><div class="grand"><span>Total</span><span><?= money($o['total']) ?></span></div></div></div>

    <div class="card"><h2>History</h2><ul class="event-list">
      <?php foreach ($events as $ev): ?><li><b><?= e(status_label($ev['to_status'])) ?></b> <span class="muted small">by <?= e($ev['actor_kind']) ?> · <?= e(dt($ev['created_at'])) ?></span><?php if ($ev['reason']): ?><div class="small"><?= e($ev['reason']) ?></div><?php endif; ?></li><?php endforeach; ?></ul></div>

    <div class="card"><h2>Money</h2>
      <h3>Payments</h3><div class="table-wrap"><table><thead><tr><th>Reference</th><th>Method</th><th class="right">Amount</th><th>Status</th><th>Recon</th></tr></thead><tbody>
        <?php foreach ($payments as $p): ?><tr><td class="mono"><?= e($p['external_ref']) ?></td><td><?= e($p['method']) ?></td><td class="right"><?= money($p['amount']) ?></td><td><?= status_badge($p['status']) ?></td><td><?= e($p['recon_status']) ?></td></tr><?php endforeach; ?>
        <?php if (!$payments): ?><tr><td colspan="5" class="empty">No payment yet.</td></tr><?php endif; ?></tbody></table></div>
      <p class="mt">Escrow: <?= $escrow ? status_badge($escrow['status']) . ' ' . money($escrow['amount']) : '<span class="muted">not held</span>' ?></p>
      <h3>Commission split</h3><div class="table-wrap"><table><thead><tr><th>Party</th><th>Who</th><th class="right">Rate</th><th class="right">Amount</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($commissions as $c): ?><tr><td><?= e(status_label($c['party'])) ?></td><td><?= e($c['name']) ?></td><td class="right"><?= rtrim(rtrim(number_format($c['rate_bps'] / 100, 2), '0'), '.') ?>%</td><td class="right"><?= money($c['amount']) ?></td><td><?= status_badge($c['status']) ?></td></tr><?php endforeach; ?>
        <?php if (!$commissions): ?><tr><td colspan="5" class="empty">Not split yet (order unpaid).</td></tr><?php endif; ?></tbody></table></div></div>
  </div>

  <div class="stack">
    <div class="card"><h2>Move order</h2>
      <?php if ($next): ?>
      <form method="post" action="/admin/orders/<?= e($o['code']) ?>/transition" data-once><?= csrf_field() ?>
        <div class="field"><label for="to">New status</label><select id="to" name="to"><?php foreach ($next as $n): ?><option value="<?= e($n) ?>"><?= e(status_label($n)) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="reason">Reason (required)</label><textarea id="reason" name="reason" required></textarea></div>
        <button class="btn btn-block" type="submit" data-confirm="Apply this change? Money moves automatically for cancel, refund and complete.">Apply</button></form>
      <?php else: ?><p class="muted">This order is final (<?= e(status_label($o['status'])) ?>).</p><?php endif; ?></div>
    <div class="card"><h2>Delivery</h2><dl class="kv"><dt>Ship to</dt><dd><?= e($o['ship_name']) ?></dd><dt>Phone</dt><dd><?= e($o['ship_phone']) ?></dd><dt>Address</dt><dd><?= e($o['ship_address']) ?></dd>
      <dt>Courier</dt><dd><?= $job ? e($job['partner'] ?: 'Unassigned') . ' · ' . e(status_label($job['status'])) : '—' ?></dd></dl></div>
    <div class="card"><h2>Disputes</h2><?php foreach ($disputes as $d): ?><p><?= status_badge($d['status']) ?> <b><?= e($d['name']) ?></b>: <?= e($d['reason']) ?><?php if ($d['resolution']): ?><br><span class="muted small">Resolution: <?= e($d['resolution']) ?></span><?php endif; ?></p><?php endforeach; ?>
      <?php if (!$disputes): ?><p class="muted">None.</p><?php else: ?><a href="/admin/disputes" class="small">Open disputes page</a><?php endif; ?></div>
  </div>
</div>
