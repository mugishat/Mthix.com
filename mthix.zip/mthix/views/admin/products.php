<div class="page-head"><h1>Products</h1></div>
<form class="filters" method="get">
  <div class="field"><label for="q">Search</label><input id="q" type="search" name="q" value="<?= e($q) ?>" placeholder="Product or store"></div>
  <div class="field"><label for="st">Status</label><select id="st" name="status" data-autosubmit><option value="">All</option>
    <?php foreach (['active','draft','suspended','archived'] as $s): ?><option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= status_label($s) ?></option><?php endforeach; ?></select></div>
  <button class="btn btn-light" type="submit">Filter</button>
</form>
<div class="card"><div class="table-wrap"><table>
  <thead><tr><th>Product</th><th>Store</th><th class="right">Price</th><th class="right">Stock</th><th>Status</th><th>Moderate</th></tr></thead><tbody>
  <?php foreach ($rows as $p): ?><tr>
    <td><div class="row" style="flex-wrap:nowrap"><?= product_thumb($p, 'sm') ?><div><a href="/product/<?= e($p['slug']) ?>"><?= e($p['name']) ?></a><div class="small muted"><?= e($p['cat_name']) ?> · <?= (int)$p['views'] ?> views</div></div></div></td>
    <td><?= e($p['store_name']) ?></td><td class="right"><?= money($p['base_price']) ?></td><td class="right"><?= (int)$p['stock'] ?></td><td><?= status_badge($p['status']) ?></td>
    <td><form method="post" action="/admin/products/<?= (int)$p['id'] ?>/status" class="row" style="gap:6px;flex-wrap:nowrap"><?= csrf_field() ?>
      <select name="status" aria-label="New status" style="width:auto"><?php foreach (['active','suspended','archived'] as $s): ?><option <?= $p['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select>
      <input type="text" name="reason" placeholder="Reason" aria-label="Reason" style="width:110px"><button class="btn btn-light btn-sm" type="submit">Apply</button></form></td></tr>
  <?php endforeach; ?><?php if (!$rows): ?><tr><td colspan="6" class="empty">No products match.</td></tr><?php endif; ?></tbody></table></div>
  <?= App\Core\View::partial('admin_pager', ['pg' => $pg]) ?></div>
<style>.thumb.sm{width:38px;height:38px;border-radius:8px;object-fit:cover;font-size:20px;flex:none}</style>
