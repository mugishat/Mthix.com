<?php
$flow = ['paid' => 'Paid', 'confirmed' => 'Confirmed', 'packed' => 'Packed', 'shipped' => 'Shipped', 'out_for_delivery' => 'Out for delivery', 'delivered' => 'Delivered', 'completed' => 'Completed'];
$keys = array_keys($flow); $idx = array_search($o['status'], $keys, true);
$when = []; foreach ($events as $ev) { $when[$ev['to_status']] = $ev['created_at']; }
?>
<div class="page-head"><div><h1>Order <?= e($o['code']) ?></h1><div class="muted">Placed <?= dt($o['created_at']) ?> · <?= e($o['store_name']) ?></div></div><?= status_badge($o['status']) ?></div>
<?php if (in_array($o['status'], ['cancelled', 'refunded'], true)): ?><div class="flash warn">This order was <?= e($o['status']) ?>. Any payment is returned to you.</div>
<?php elseif ($o['status'] === 'pending_payment'): ?><div class="flash warn">Waiting for payment. <a href="/pay/<?= e($o['group_code']) ?>">Pay now</a></div>
<?php else: ?>
<div class="card mb"><ol class="timeline"><?php foreach ($flow as $k => $l): $i = array_search($k, $keys, true); $cls = $idx !== false && $i < $idx ? 'done' : ($i === $idx ? 'done cur' : ''); ?>
  <li class="<?= $cls ?>"><i><?= $i <= $idx ? '✓' : $i + 1 ?></i><b><?= e($l) ?></b><span><?= isset($when[$k]) ? dt($when[$k], 'M j, H:i') : '' ?></span></li><?php endforeach; ?></ol></div>
<?php endif; ?>
<?php if (in_array($o['status'], ['out_for_delivery', 'shipped'], true)): ?><div class="flash success">Your delivery code is <b style="font-size:20px;letter-spacing:3px"><?= e($o['delivery_code']) ?></b>. Give it to the courier <u>only</u> when you hold your parcel.</div><?php endif; ?>
<div class="grid g-main">
  <div class="stack">
    <div class="card"><h3>Items</h3><div class="table-wrap"><table><tbody><?php foreach ($items as $i): ?>
      <tr><td><a href="/product/<?= e($i['slug']) ?>"><b><?= e($i['product_name']) ?></b></a><div class="small muted"><?= e((string)$i['variant_label']) ?></div></td><td><?= (int)$i['qty'] ?> × <?= money($i['unit_price']) ?></td><td class="right"><b><?= money($i['line_total']) ?></b></td></tr>
      <?php if ($o['status'] === 'completed' && !in_array($i['product_id'], $reviewed)): ?><tr><td colspan="3"><form method="post" action="/account/orders/<?= e($o['code']) ?>/review" class="row"><?= csrf_field() ?><input type="hidden" name="product_id" value="<?= (int)$i['product_id'] ?>">
        <select name="rating" style="width:auto" aria-label="Rating"><?php for ($r = 5; $r >= 1; $r--): ?><option value="<?= $r ?>"><?= str_repeat('★', $r) ?></option><?php endfor; ?></select><input type="text" name="comment" placeholder="Write a short review" class="grow"><button class="btn btn-sm" type="submit">Review</button></form></td></tr><?php endif; ?>
      <?php endforeach; ?></tbody></table></div></div>
    <div class="card"><h3>History</h3><ul class="event-list"><?php foreach ($events as $ev): ?><li><b><?= e(status_label($ev['to_status'])) ?></b> <span class="muted small"><?= dt($ev['created_at']) ?> · <?= e($ev['actor_kind']) ?><?= $ev['reason'] ? ' · ' . e($ev['reason']) : '' ?></span></li><?php endforeach; ?></ul></div>
  </div>
  <div class="stack">
    <div class="card totals"><h3>Summary</h3><div><span>Items</span><b><?= money($o['subtotal']) ?></b></div><div><span>Delivery</span><b><?= money($o['delivery_fee']) ?></b></div><div class="grand"><span>Total</span><b><?= money($o['total']) ?></b></div></div>
    <div class="card"><h3>Delivery</h3><p><?= e($o['ship_name']) ?><br><?= e($o['ship_phone']) ?><br><?= nl2br(e($o['ship_address'])) ?></p>
      <?php if ($courier): ?><p class="small muted">Courier: <?= e($courier['name']) ?> · <?= e((string)$courier['phone']) ?></p><?php endif; ?></div>
    <?php if ($canConfirm): ?><div class="card"><h3>Got your order?</h3><p class="small muted">Confirming releases the money to the seller.</p>
      <form method="post" action="/account/orders/<?= e($o['code']) ?>/confirm" data-once><?= csrf_field() ?><button class="btn btn-block" type="submit" data-confirm="Confirm you received everything in good condition?">Confirm receipt</button></form></div><?php endif; ?>
    <?php if ($canCancel): ?><form method="post" action="/account/orders/<?= e($o['code']) ?>/cancel"><?= csrf_field() ?><button class="btn btn-danger btn-block" type="submit" data-confirm="Cancel this order?">Cancel order</button></form><?php endif; ?>
    <?php if (in_array($o['status'], ['shipped', 'out_for_delivery', 'delivered'], true)): ?><div class="card"><h3>Problem with this order?</h3>
      <?php if ($dispute): ?><p>Dispute <?= status_badge($dispute['status']) ?></p><p class="small muted"><?= e($dispute['reason']) ?></p><?= $dispute['resolution'] ? '<p>' . e($dispute['resolution']) . '</p>' : '' ?>
      <?php else: ?><form method="post" action="/account/orders/<?= e($o['code']) ?>/dispute"><?= csrf_field() ?><div class="field"><textarea name="reason" placeholder="Describe what went wrong" required></textarea></div><button class="btn btn-light btn-block" type="submit">Open dispute</button></form><?php endif; ?></div><?php endif; ?>
  </div>
</div>
