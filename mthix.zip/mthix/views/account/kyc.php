<h1>Identity verification (KYC)</h1>
<p class="muted">Required before your first withdrawal. We store only what is needed to prevent fraud.</p>
<?php if ($me['kyc_status'] === 'verified'): ?><div class="flash success">✔ You are verified. You can withdraw earnings.</div>
<?php elseif ($me['kyc_status'] === 'pending'): ?><div class="flash info">Your documents are under review. We will notify you.</div>
<?php else: ?>
<?php if ($me['kyc_status'] === 'rejected' && $rec): ?><div class="flash error">Your last submission was rejected<?= $rec['note'] ? ': ' . e($rec['note']) : '' ?>. Please submit again.</div><?php endif; ?>
<form class="card mt" method="post" action="/kyc" style="max-width:560px" data-once><?= csrf_field() ?>
  <div class="field"><label for="f">Full legal name</label><input id="f" type="text" name="full_name" required value="<?= e($me['name']) ?>"></div>
  <div class="form-grid"><div class="field"><label for="t">Document type</label><select id="t" name="doc_type"><option value="national_id">National ID</option><option value="passport">Passport</option><option value="driving_licence">Driving licence</option></select></div>
  <div class="field"><label for="d">Document number</label><input id="d" type="text" name="doc_number" required></div></div>
  <div class="field"><label for="tin">Business TIN (sellers, optional)</label><input id="tin" type="text" name="business_tin"></div>
  <div class="field"><label for="pa">Payout account (MoMo number or bank)</label><input id="pa" type="text" name="payout_account"></div>
  <button class="btn" type="submit">Submit for review</button></form>
<?php endif; ?>
