<div class="page-head"><div><h1>Products to promote</h1><p class="muted">You earn <?= e((string)$rate) ?>% of the product price when the buyer's order completes.</p></div></div>
<?php if (!$items): ?><div class="card empty">No products are open to resellers yet.</div><?php else: ?>
<div class="card table-wrap"><table>
<thead><tr><th>Product</th><th>Store</th><th>Price</th><th>Stock</th><th>Your commission</th><th>Share link</th></tr></thead><tbody>
<?php foreach ($items as $i): $link = url('/product/' . $i['slug'] . '?r=' . $ref); ?>
<tr><td><a href="/product/<?= e($i['slug']) ?>"><?= e($i['name']) ?></a></td><td><?= e($i['store_name']) ?></td><td><?= money($i['base_price']) ?></td>
<td><?= (int)$i['stock'] ?></td><td class="pos"><?= money($i['commission']) ?></td>
<td><button class="btn btn-light btn-sm" type="button" data-copy="<?= e($link) ?>">Copy link</button></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?>
