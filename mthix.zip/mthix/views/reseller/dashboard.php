<div class="page-head"><div><h1>Reseller dashboard</h1><p class="muted">Share products, earn commission on every completed sale.</p></div>
  <a class="btn" href="/reseller/products">Find products to promote</a></div>
<div class="grid g4 mb">
  <div class="card stat"><span class="ico">₣</span><div><div class="lbl">Available</div><div class="val"><?= money($bal['available']) ?></div></div></div>
  <div class="card stat"><span class="ico a">⏳</span><div><div class="lbl">Pending</div><div class="val"><?= money($bal['pending']) ?></div></div></div>
  <div class="card stat"><span class="ico b">⛓</span><div><div class="lbl">Clicks</div><div class="val"><?= number_format($clicks) ?></div></div></div>
  <div class="card stat"><span class="ico p">%</span><div><div class="lbl">Orders · conversion</div><div class="val"><?= (int)$orders ?> · <?= $conv ?>%</div></div></div>
</div>
<div class="grid g-main">
  <div class="card"><div class="card-head"><h2>Commission earned (14 days)</h2><span class="muted small">Total earnings <?= money($bal['total_earnings']) ?></span></div>
    <?= chart_bars(array_map(fn($d) => date('j M', strtotime($d)), array_keys($days)), array_values($days)) ?></div>
  <div class="card"><h2>Your link</h2>
    <p class="small muted">Open any product page and add your code. You earn only on the product you shared.</p>
    <p><code>?r=<?= e($ref) ?></code></p>
    <button class="btn btn-light btn-sm" type="button" data-copy="<?= e($ref) ?>">Copy code</button>
    <p class="small muted mt">Sales driven: <b><?= money($sales) ?></b></p></div>
</div>
<div class="card mt"><div class="card-head"><h2>Recent orders</h2><a href="/reseller/orders">View all</a></div>
<?= \App\Core\View::partial('partner_orders', ['rows' => $recent]) ?></div>
