<?php
declare(strict_types=1);

// Front controller. With PHP's built-in server:  php -S 0.0.0.0:8000 -t public public/index.php
if (PHP_SAPI === 'cli-server') {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($path !== '/' && is_file(__DIR__ . $path)) {
        return false; // serve static files (css, js, uploads) directly
    }
}

require __DIR__ . '/../app/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    App\Services\Referral::capture();
}

$router = require ROOT . '/app/routes.php';

try {
    $router->dispatch();
} catch (Throwable $e) {
    error_log((string)$e);
    if (cfg('env') === 'dev') {
        http_response_code(500);
        echo '<pre style="padding:20px;white-space:pre-wrap">' . htmlspecialchars((string)$e) . '</pre>';
        exit;
    }
    abort(500, 'Please try again. If it keeps happening, contact support.');
}
