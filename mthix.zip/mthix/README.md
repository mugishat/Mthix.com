# MTHIX marketplace (MVP)

PHP 8.1+ with SQLite. No Composer or npm needed.

## Run it
    php cli/install.php                          # creates data/mthix.sqlite with demo data
    php -S 0.0.0.0:8000 -t public public/index.php
    open http://localhost:8000

Demo accounts (password `Mthix@2026`): buyer@mthix.rw, seller@mthix.rw, reseller@mthix.rw, affiliate@mthix.rw,
delivery@mthix.rw, admin@mthix.rw, finance@mthix.rw, support@mthix.rw. CHANGE THESE before going live.

## Tests
    php tests/run.php        # 67 business-rule checks (commission, escrow, ledger, webhooks, stock races, withdrawals)

## Before production
- Set MTHIX_ENV=prod and a real MTHIX_WEBHOOK_SECRET. In dev, /pay/{group} shows "simulate payment" buttons; they are disabled in prod.
- Connect the real MTN MoMo / Airtel / card gateway: it must POST signed JSON {reference,status,amount} to /webhooks/payment (header X-Signature = HMAC-SHA256 of the body).
- Cron: `php cli/expire_orders.php` every 5 min and `php cli/auto_complete.php` hourly.
- Serve over HTTPS; back up data/mthix.sqlite (or move to MySQL/PostgreSQL).
