<?php
// MTHIX configuration. Override secrets with environment variables in production.
return [
    'app_name'           => 'MTHIX',
    'env'                => getenv('MTHIX_ENV') ?: 'dev',
    'db_path'            => getenv('MTHIX_DB') ?: ROOT . '/data/mthix.sqlite',
    'webhook_secret'     => getenv('MTHIX_WEBHOOK_SECRET') ?: 'dev-webhook-secret-change-me',
    'platform_user_id'   => 1,      // the MTHIX platform account (receives platform commission)
    'attribution_days'   => 30,     // reseller / affiliate attribution window
    'min_withdrawal'     => 5000,   // RWF
    'review_threshold'   => 500000, // withdrawals at/above this go to manual review
    'new_account_days'   => 7,      // withdrawals from accounts younger than this go to review
    'reservation_minutes'=> 30,     // unpaid orders release their stock after this long
    'auto_complete_days' => 7,      // delivered orders auto-complete after this long
    'vat_percent'        => 18,     // prices are VAT-inclusive; shown for information
    'delivery_methods'   => [
        'mthix' => ['label' => 'MTHIX Delivery', 'eta' => '1-2 days', 'fee' => 3000],
        'speed' => ['label' => 'Speed Post',     'eta' => '2-3 days', 'fee' => 5000],
        'dhl'   => ['label' => 'DHL Express',    'eta' => '1 day',    'fee' => 10000],
    ],
    'payment_methods'    => [
        'mtn'    => 'MTN Mobile Money',
        'airtel' => 'Airtel Money',
        'card'   => 'Visa / Mastercard',
    ],
];
